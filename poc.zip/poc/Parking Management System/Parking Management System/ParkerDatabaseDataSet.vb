﻿Partial Class ParkerDatabaseDataSet
    Partial Class loginDataTable

        Private Sub loginDataTable_loginRowChanging(ByVal sender As System.Object, ByVal e As loginRowChangeEvent) Handles Me.loginRowChanging

        End Sub

    End Class

End Class
