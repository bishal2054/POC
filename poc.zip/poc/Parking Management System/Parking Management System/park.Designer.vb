﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class park
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.f11 = New System.Windows.Forms.Label()
        Me.f13 = New System.Windows.Forms.Label()
        Me.f9 = New System.Windows.Forms.Label()
        Me.f18 = New System.Windows.Forms.Label()
        Me.f20 = New System.Windows.Forms.Label()
        Me.f16 = New System.Windows.Forms.Label()
        Me.f17 = New System.Windows.Forms.Label()
        Me.f19 = New System.Windows.Forms.Label()
        Me.f15 = New System.Windows.Forms.Label()
        Me.f12 = New System.Windows.Forms.Label()
        Me.f14 = New System.Windows.Forms.Label()
        Me.f10 = New System.Windows.Forms.Label()
        Me.f5 = New System.Windows.Forms.Label()
        Me.f7 = New System.Windows.Forms.Label()
        Me.f3 = New System.Windows.Forms.Label()
        Me.f1 = New System.Windows.Forms.Label()
        Me.f6 = New System.Windows.Forms.Label()
        Me.f8 = New System.Windows.Forms.Label()
        Me.f4 = New System.Windows.Forms.Label()
        Me.f2 = New System.Windows.Forms.Label()
        Me.t18 = New System.Windows.Forms.Label()
        Me.t19 = New System.Windows.Forms.Label()
        Me.t20 = New System.Windows.Forms.Label()
        Me.t17 = New System.Windows.Forms.Label()
        Me.t16 = New System.Windows.Forms.Label()
        Me.t13 = New System.Windows.Forms.Label()
        Me.t14 = New System.Windows.Forms.Label()
        Me.t15 = New System.Windows.Forms.Label()
        Me.t12 = New System.Windows.Forms.Label()
        Me.t11 = New System.Windows.Forms.Label()
        Me.t5 = New System.Windows.Forms.Label()
        Me.t6 = New System.Windows.Forms.Label()
        Me.t7 = New System.Windows.Forms.Label()
        Me.t8 = New System.Windows.Forms.Label()
        Me.t9 = New System.Windows.Forms.Label()
        Me.t10 = New System.Windows.Forms.Label()
        Me.t3 = New System.Windows.Forms.Label()
        Me.t4 = New System.Windows.Forms.Label()
        Me.t26 = New System.Windows.Forms.Label()
        Me.t25 = New System.Windows.Forms.Label()
        Me.t24 = New System.Windows.Forms.Label()
        Me.t23 = New System.Windows.Forms.Label()
        Me.t22 = New System.Windows.Forms.Label()
        Me.t21 = New System.Windows.Forms.Label()
        Me.t28 = New System.Windows.Forms.Label()
        Me.t27 = New System.Windows.Forms.Label()
        Me.t34 = New System.Windows.Forms.Label()
        Me.t33 = New System.Windows.Forms.Label()
        Me.t32 = New System.Windows.Forms.Label()
        Me.t31 = New System.Windows.Forms.Label()
        Me.t30 = New System.Windows.Forms.Label()
        Me.t29 = New System.Windows.Forms.Label()
        Me.t1 = New System.Windows.Forms.Label()
        Me.t2 = New System.Windows.Forms.Label()
        Me.t48 = New System.Windows.Forms.Label()
        Me.t47 = New System.Windows.Forms.Label()
        Me.t46 = New System.Windows.Forms.Label()
        Me.t45 = New System.Windows.Forms.Label()
        Me.t44 = New System.Windows.Forms.Label()
        Me.t43 = New System.Windows.Forms.Label()
        Me.t42 = New System.Windows.Forms.Label()
        Me.t41 = New System.Windows.Forms.Label()
        Me.t40 = New System.Windows.Forms.Label()
        Me.t39 = New System.Windows.Forms.Label()
        Me.t38 = New System.Windows.Forms.Label()
        Me.t37 = New System.Windows.Forms.Label()
        Me.t36 = New System.Windows.Forms.Label()
        Me.t35 = New System.Windows.Forms.Label()
        Me.t49 = New System.Windows.Forms.Label()
        Me.t50 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 64)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SplitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer1.Panel1.Controls.Add(Me.PictureBox7)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel3)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label5)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label4)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label3)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.Color.White
        Me.SplitContainer1.Panel2.BackgroundImage = Global.Parking_Management_System.My.Resources.Resources.park
        Me.SplitContainer1.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer1.Panel2.Controls.Add(Me.f11)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f13)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f9)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f18)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f20)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f16)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f17)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f19)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f15)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f12)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f14)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f10)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f5)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f7)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f3)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f6)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f8)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f4)
        Me.SplitContainer1.Panel2.Controls.Add(Me.f2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t18)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t19)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t20)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t17)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t16)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t13)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t14)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t15)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t12)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t11)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t5)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t6)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t7)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t8)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t9)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t10)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t3)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t4)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t26)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t25)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t24)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t23)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t22)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t21)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t28)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t27)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t34)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t33)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t32)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t31)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t30)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t29)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t48)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t47)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t46)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t45)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t44)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t43)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t42)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t41)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t40)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t39)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t38)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t37)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t36)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t35)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t49)
        Me.SplitContainer1.Panel2.Controls.Add(Me.t50)
        Me.SplitContainer1.Size = New System.Drawing.Size(2042, 920)
        Me.SplitContainer1.SplitterDistance = 398
        Me.SplitContainer1.TabIndex = 3
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.Parking_Management_System.My.Resources.Resources.home1
        Me.PictureBox7.Location = New System.Drawing.Point(101, 75)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(99, 81)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 21
        Me.PictureBox7.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Red
        Me.Panel3.Location = New System.Drawing.Point(256, 342)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(36, 32)
        Me.Panel3.TabIndex = 12
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LimeGreen
        Me.Panel2.Location = New System.Drawing.Point(256, 250)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(36, 32)
        Me.Panel2.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Footlight MT Light", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(84, 342)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 33)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Parked"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Footlight MT Light", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(84, 250)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(127, 33)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Available"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Footlight MT Light", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(49, 487)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(277, 30)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = """ t "" is for two wheelers"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Footlight MT Light", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(49, 577)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(284, 30)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = """ f "" is for four wheelers"
        '
        'f11
        '
        Me.f11.AutoSize = True
        Me.f11.BackColor = System.Drawing.Color.LimeGreen
        Me.f11.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f11.Location = New System.Drawing.Point(841, 381)
        Me.f11.Name = "f11"
        Me.f11.Size = New System.Drawing.Size(58, 32)
        Me.f11.TabIndex = 260
        Me.f11.Text = "f11"
        '
        'f13
        '
        Me.f13.AutoSize = True
        Me.f13.BackColor = System.Drawing.Color.LimeGreen
        Me.f13.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f13.Location = New System.Drawing.Point(957, 381)
        Me.f13.Name = "f13"
        Me.f13.Size = New System.Drawing.Size(58, 32)
        Me.f13.TabIndex = 259
        Me.f13.Text = "f13"
        '
        'f9
        '
        Me.f9.AutoSize = True
        Me.f9.BackColor = System.Drawing.Color.LimeGreen
        Me.f9.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f9.Location = New System.Drawing.Point(733, 381)
        Me.f9.Name = "f9"
        Me.f9.Size = New System.Drawing.Size(41, 32)
        Me.f9.TabIndex = 258
        Me.f9.Text = "f9"
        '
        'f18
        '
        Me.f18.AutoSize = True
        Me.f18.BackColor = System.Drawing.Color.LimeGreen
        Me.f18.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f18.Location = New System.Drawing.Point(841, 277)
        Me.f18.Name = "f18"
        Me.f18.Size = New System.Drawing.Size(58, 32)
        Me.f18.TabIndex = 257
        Me.f18.Text = "f18"
        '
        'f20
        '
        Me.f20.AutoSize = True
        Me.f20.BackColor = System.Drawing.Color.LimeGreen
        Me.f20.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f20.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f20.Location = New System.Drawing.Point(957, 277)
        Me.f20.Name = "f20"
        Me.f20.Size = New System.Drawing.Size(58, 32)
        Me.f20.TabIndex = 256
        Me.f20.Text = "f20"
        '
        'f16
        '
        Me.f16.AutoSize = True
        Me.f16.BackColor = System.Drawing.Color.LimeGreen
        Me.f16.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f16.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f16.Location = New System.Drawing.Point(723, 277)
        Me.f16.Name = "f16"
        Me.f16.Size = New System.Drawing.Size(58, 32)
        Me.f16.TabIndex = 255
        Me.f16.Text = "f16"
        '
        'f17
        '
        Me.f17.AutoSize = True
        Me.f17.BackColor = System.Drawing.Color.LimeGreen
        Me.f17.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f17.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f17.Location = New System.Drawing.Point(841, 215)
        Me.f17.Name = "f17"
        Me.f17.Size = New System.Drawing.Size(58, 32)
        Me.f17.TabIndex = 254
        Me.f17.Text = "f17"
        '
        'f19
        '
        Me.f19.AutoSize = True
        Me.f19.BackColor = System.Drawing.Color.LimeGreen
        Me.f19.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f19.Location = New System.Drawing.Point(955, 215)
        Me.f19.Name = "f19"
        Me.f19.Size = New System.Drawing.Size(58, 32)
        Me.f19.TabIndex = 253
        Me.f19.Text = "f19"
        '
        'f15
        '
        Me.f15.AutoSize = True
        Me.f15.BackColor = System.Drawing.Color.LimeGreen
        Me.f15.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f15.Location = New System.Drawing.Point(723, 215)
        Me.f15.Name = "f15"
        Me.f15.Size = New System.Drawing.Size(58, 32)
        Me.f15.TabIndex = 252
        Me.f15.Text = "f15"
        '
        'f12
        '
        Me.f12.AutoSize = True
        Me.f12.BackColor = System.Drawing.Color.LimeGreen
        Me.f12.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f12.Location = New System.Drawing.Point(841, 448)
        Me.f12.Name = "f12"
        Me.f12.Size = New System.Drawing.Size(58, 32)
        Me.f12.TabIndex = 251
        Me.f12.Text = "f12"
        '
        'f14
        '
        Me.f14.AutoSize = True
        Me.f14.BackColor = System.Drawing.Color.LimeGreen
        Me.f14.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f14.Location = New System.Drawing.Point(957, 448)
        Me.f14.Name = "f14"
        Me.f14.Size = New System.Drawing.Size(58, 32)
        Me.f14.TabIndex = 250
        Me.f14.Text = "f14"
        '
        'f10
        '
        Me.f10.AutoSize = True
        Me.f10.BackColor = System.Drawing.Color.LimeGreen
        Me.f10.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f10.Location = New System.Drawing.Point(726, 448)
        Me.f10.Name = "f10"
        Me.f10.Size = New System.Drawing.Size(58, 32)
        Me.f10.TabIndex = 249
        Me.f10.Text = "f10"
        '
        'f5
        '
        Me.f5.AutoSize = True
        Me.f5.BackColor = System.Drawing.Color.LimeGreen
        Me.f5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f5.Location = New System.Drawing.Point(812, 577)
        Me.f5.Name = "f5"
        Me.f5.Size = New System.Drawing.Size(41, 32)
        Me.f5.TabIndex = 248
        Me.f5.Text = "f5"
        '
        'f7
        '
        Me.f7.AutoSize = True
        Me.f7.BackColor = System.Drawing.Color.LimeGreen
        Me.f7.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f7.Location = New System.Drawing.Point(942, 575)
        Me.f7.Name = "f7"
        Me.f7.Size = New System.Drawing.Size(41, 32)
        Me.f7.TabIndex = 247
        Me.f7.Text = "f7"
        '
        'f3
        '
        Me.f3.AutoSize = True
        Me.f3.BackColor = System.Drawing.Color.LimeGreen
        Me.f3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f3.Location = New System.Drawing.Point(677, 575)
        Me.f3.Name = "f3"
        Me.f3.Size = New System.Drawing.Size(41, 32)
        Me.f3.TabIndex = 246
        Me.f3.Text = "f3"
        '
        'f1
        '
        Me.f1.AutoSize = True
        Me.f1.BackColor = System.Drawing.Color.LimeGreen
        Me.f1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f1.Location = New System.Drawing.Point(545, 577)
        Me.f1.Name = "f1"
        Me.f1.Size = New System.Drawing.Size(41, 32)
        Me.f1.TabIndex = 245
        Me.f1.Text = "f1"
        '
        'f6
        '
        Me.f6.AutoSize = True
        Me.f6.BackColor = System.Drawing.Color.LimeGreen
        Me.f6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f6.Location = New System.Drawing.Point(812, 637)
        Me.f6.Name = "f6"
        Me.f6.Size = New System.Drawing.Size(41, 32)
        Me.f6.TabIndex = 244
        Me.f6.Text = "f6"
        '
        'f8
        '
        Me.f8.AutoSize = True
        Me.f8.BackColor = System.Drawing.Color.LimeGreen
        Me.f8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f8.Location = New System.Drawing.Point(942, 637)
        Me.f8.Name = "f8"
        Me.f8.Size = New System.Drawing.Size(41, 32)
        Me.f8.TabIndex = 243
        Me.f8.Text = "f8"
        '
        'f4
        '
        Me.f4.AutoSize = True
        Me.f4.BackColor = System.Drawing.Color.LimeGreen
        Me.f4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f4.Location = New System.Drawing.Point(677, 637)
        Me.f4.Name = "f4"
        Me.f4.Size = New System.Drawing.Size(41, 32)
        Me.f4.TabIndex = 242
        Me.f4.Text = "f4"
        '
        'f2
        '
        Me.f2.AutoSize = True
        Me.f2.BackColor = System.Drawing.Color.LimeGreen
        Me.f2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.f2.Location = New System.Drawing.Point(545, 637)
        Me.f2.Name = "f2"
        Me.f2.Size = New System.Drawing.Size(41, 32)
        Me.f2.TabIndex = 241
        Me.f2.Text = "f2"
        '
        't18
        '
        Me.t18.AutoSize = True
        Me.t18.BackColor = System.Drawing.Color.LimeGreen
        Me.t18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t18.Location = New System.Drawing.Point(1096, 99)
        Me.t18.Name = "t18"
        Me.t18.Size = New System.Drawing.Size(42, 25)
        Me.t18.TabIndex = 240
        Me.t18.Text = "t18"
        '
        't19
        '
        Me.t19.AutoSize = True
        Me.t19.BackColor = System.Drawing.Color.LimeGreen
        Me.t19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t19.Location = New System.Drawing.Point(1163, 99)
        Me.t19.Name = "t19"
        Me.t19.Size = New System.Drawing.Size(42, 25)
        Me.t19.TabIndex = 239
        Me.t19.Text = "t19"
        '
        't20
        '
        Me.t20.AutoSize = True
        Me.t20.BackColor = System.Drawing.Color.LimeGreen
        Me.t20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t20.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t20.Location = New System.Drawing.Point(1229, 99)
        Me.t20.Name = "t20"
        Me.t20.Size = New System.Drawing.Size(42, 25)
        Me.t20.TabIndex = 238
        Me.t20.Text = "t20"
        '
        't17
        '
        Me.t17.AutoSize = True
        Me.t17.BackColor = System.Drawing.Color.LimeGreen
        Me.t17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t17.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t17.Location = New System.Drawing.Point(1032, 99)
        Me.t17.Name = "t17"
        Me.t17.Size = New System.Drawing.Size(42, 25)
        Me.t17.TabIndex = 237
        Me.t17.Text = "t17"
        '
        't16
        '
        Me.t16.AutoSize = True
        Me.t16.BackColor = System.Drawing.Color.LimeGreen
        Me.t16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t16.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t16.Location = New System.Drawing.Point(966, 99)
        Me.t16.Name = "t16"
        Me.t16.Size = New System.Drawing.Size(42, 25)
        Me.t16.TabIndex = 236
        Me.t16.Text = "t16"
        '
        't13
        '
        Me.t13.AutoSize = True
        Me.t13.BackColor = System.Drawing.Color.LimeGreen
        Me.t13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t13.Location = New System.Drawing.Point(635, 99)
        Me.t13.Name = "t13"
        Me.t13.Size = New System.Drawing.Size(42, 25)
        Me.t13.TabIndex = 235
        Me.t13.Text = "t13"
        '
        't14
        '
        Me.t14.AutoSize = True
        Me.t14.BackColor = System.Drawing.Color.LimeGreen
        Me.t14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t14.Location = New System.Drawing.Point(702, 99)
        Me.t14.Name = "t14"
        Me.t14.Size = New System.Drawing.Size(42, 25)
        Me.t14.TabIndex = 234
        Me.t14.Text = "t14"
        '
        't15
        '
        Me.t15.AutoSize = True
        Me.t15.BackColor = System.Drawing.Color.LimeGreen
        Me.t15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t15.Location = New System.Drawing.Point(773, 99)
        Me.t15.Name = "t15"
        Me.t15.Size = New System.Drawing.Size(42, 25)
        Me.t15.TabIndex = 233
        Me.t15.Text = "t15"
        '
        't12
        '
        Me.t12.AutoSize = True
        Me.t12.BackColor = System.Drawing.Color.LimeGreen
        Me.t12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t12.Location = New System.Drawing.Point(569, 99)
        Me.t12.Name = "t12"
        Me.t12.Size = New System.Drawing.Size(42, 25)
        Me.t12.TabIndex = 232
        Me.t12.Text = "t12"
        '
        't11
        '
        Me.t11.AutoSize = True
        Me.t11.BackColor = System.Drawing.Color.LimeGreen
        Me.t11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t11.Location = New System.Drawing.Point(508, 99)
        Me.t11.Name = "t11"
        Me.t11.Size = New System.Drawing.Size(42, 25)
        Me.t11.TabIndex = 231
        Me.t11.Text = "t11"
        '
        't5
        '
        Me.t5.AutoSize = True
        Me.t5.BackColor = System.Drawing.Color.LimeGreen
        Me.t5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t5.Location = New System.Drawing.Point(431, 326)
        Me.t5.Name = "t5"
        Me.t5.Size = New System.Drawing.Size(30, 25)
        Me.t5.TabIndex = 230
        Me.t5.Text = "t5"
        '
        't6
        '
        Me.t6.AutoSize = True
        Me.t6.BackColor = System.Drawing.Color.LimeGreen
        Me.t6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t6.Location = New System.Drawing.Point(431, 290)
        Me.t6.Name = "t6"
        Me.t6.Size = New System.Drawing.Size(30, 25)
        Me.t6.TabIndex = 229
        Me.t6.Text = "t6"
        '
        't7
        '
        Me.t7.AutoSize = True
        Me.t7.BackColor = System.Drawing.Color.LimeGreen
        Me.t7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t7.Location = New System.Drawing.Point(431, 255)
        Me.t7.Name = "t7"
        Me.t7.Size = New System.Drawing.Size(30, 25)
        Me.t7.TabIndex = 228
        Me.t7.Text = "t7"
        '
        't8
        '
        Me.t8.AutoSize = True
        Me.t8.BackColor = System.Drawing.Color.LimeGreen
        Me.t8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t8.Location = New System.Drawing.Point(431, 218)
        Me.t8.Name = "t8"
        Me.t8.Size = New System.Drawing.Size(30, 25)
        Me.t8.TabIndex = 227
        Me.t8.Text = "t8"
        '
        't9
        '
        Me.t9.AutoSize = True
        Me.t9.BackColor = System.Drawing.Color.LimeGreen
        Me.t9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t9.Location = New System.Drawing.Point(431, 181)
        Me.t9.Name = "t9"
        Me.t9.Size = New System.Drawing.Size(30, 25)
        Me.t9.TabIndex = 226
        Me.t9.Text = "t9"
        '
        't10
        '
        Me.t10.AutoSize = True
        Me.t10.BackColor = System.Drawing.Color.LimeGreen
        Me.t10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t10.Location = New System.Drawing.Point(431, 146)
        Me.t10.Name = "t10"
        Me.t10.Size = New System.Drawing.Size(42, 25)
        Me.t10.TabIndex = 225
        Me.t10.Text = "t10"
        '
        't3
        '
        Me.t3.AutoSize = True
        Me.t3.BackColor = System.Drawing.Color.LimeGreen
        Me.t3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t3.Location = New System.Drawing.Point(431, 401)
        Me.t3.Name = "t3"
        Me.t3.Size = New System.Drawing.Size(30, 25)
        Me.t3.TabIndex = 224
        Me.t3.Text = "t3"
        '
        't4
        '
        Me.t4.AutoSize = True
        Me.t4.BackColor = System.Drawing.Color.LimeGreen
        Me.t4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t4.Location = New System.Drawing.Point(431, 362)
        Me.t4.Name = "t4"
        Me.t4.Size = New System.Drawing.Size(30, 25)
        Me.t4.TabIndex = 223
        Me.t4.Text = "t4"
        '
        't26
        '
        Me.t26.AutoSize = True
        Me.t26.BackColor = System.Drawing.Color.LimeGreen
        Me.t26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t26.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t26.Location = New System.Drawing.Point(1300, 330)
        Me.t26.Name = "t26"
        Me.t26.Size = New System.Drawing.Size(42, 25)
        Me.t26.TabIndex = 222
        Me.t26.Text = "t26"
        '
        't25
        '
        Me.t25.AutoSize = True
        Me.t25.BackColor = System.Drawing.Color.LimeGreen
        Me.t25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t25.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t25.Location = New System.Drawing.Point(1300, 291)
        Me.t25.Name = "t25"
        Me.t25.Size = New System.Drawing.Size(42, 25)
        Me.t25.TabIndex = 221
        Me.t25.Text = "t25"
        '
        't24
        '
        Me.t24.AutoSize = True
        Me.t24.BackColor = System.Drawing.Color.LimeGreen
        Me.t24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t24.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t24.Location = New System.Drawing.Point(1300, 253)
        Me.t24.Name = "t24"
        Me.t24.Size = New System.Drawing.Size(42, 25)
        Me.t24.TabIndex = 220
        Me.t24.Text = "t24"
        '
        't23
        '
        Me.t23.AutoSize = True
        Me.t23.BackColor = System.Drawing.Color.LimeGreen
        Me.t23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t23.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t23.Location = New System.Drawing.Point(1300, 219)
        Me.t23.Name = "t23"
        Me.t23.Size = New System.Drawing.Size(42, 25)
        Me.t23.TabIndex = 219
        Me.t23.Text = "t23"
        '
        't22
        '
        Me.t22.AutoSize = True
        Me.t22.BackColor = System.Drawing.Color.LimeGreen
        Me.t22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t22.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t22.Location = New System.Drawing.Point(1300, 184)
        Me.t22.Name = "t22"
        Me.t22.Size = New System.Drawing.Size(42, 25)
        Me.t22.TabIndex = 218
        Me.t22.Text = "t22"
        '
        't21
        '
        Me.t21.AutoSize = True
        Me.t21.BackColor = System.Drawing.Color.LimeGreen
        Me.t21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t21.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t21.Location = New System.Drawing.Point(1300, 148)
        Me.t21.Name = "t21"
        Me.t21.Size = New System.Drawing.Size(42, 25)
        Me.t21.TabIndex = 217
        Me.t21.Text = "t21"
        '
        't28
        '
        Me.t28.AutoSize = True
        Me.t28.BackColor = System.Drawing.Color.LimeGreen
        Me.t28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t28.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t28.Location = New System.Drawing.Point(1300, 404)
        Me.t28.Name = "t28"
        Me.t28.Size = New System.Drawing.Size(42, 25)
        Me.t28.TabIndex = 216
        Me.t28.Text = "t28"
        '
        't27
        '
        Me.t27.AutoSize = True
        Me.t27.BackColor = System.Drawing.Color.LimeGreen
        Me.t27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t27.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t27.Location = New System.Drawing.Point(1300, 368)
        Me.t27.Name = "t27"
        Me.t27.Size = New System.Drawing.Size(42, 25)
        Me.t27.TabIndex = 215
        Me.t27.Text = "t27"
        '
        't34
        '
        Me.t34.AutoSize = True
        Me.t34.BackColor = System.Drawing.Color.LimeGreen
        Me.t34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t34.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t34.Location = New System.Drawing.Point(1300, 658)
        Me.t34.Name = "t34"
        Me.t34.Size = New System.Drawing.Size(42, 25)
        Me.t34.TabIndex = 214
        Me.t34.Text = "t34"
        '
        't33
        '
        Me.t33.AutoSize = True
        Me.t33.BackColor = System.Drawing.Color.LimeGreen
        Me.t33.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t33.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t33.Location = New System.Drawing.Point(1300, 622)
        Me.t33.Name = "t33"
        Me.t33.Size = New System.Drawing.Size(42, 25)
        Me.t33.TabIndex = 213
        Me.t33.Text = "t33"
        '
        't32
        '
        Me.t32.AutoSize = True
        Me.t32.BackColor = System.Drawing.Color.LimeGreen
        Me.t32.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t32.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t32.Location = New System.Drawing.Point(1300, 587)
        Me.t32.Name = "t32"
        Me.t32.Size = New System.Drawing.Size(42, 25)
        Me.t32.TabIndex = 212
        Me.t32.Text = "t32"
        '
        't31
        '
        Me.t31.AutoSize = True
        Me.t31.BackColor = System.Drawing.Color.LimeGreen
        Me.t31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t31.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t31.Location = New System.Drawing.Point(1300, 550)
        Me.t31.Name = "t31"
        Me.t31.Size = New System.Drawing.Size(42, 25)
        Me.t31.TabIndex = 211
        Me.t31.Text = "t31"
        '
        't30
        '
        Me.t30.AutoSize = True
        Me.t30.BackColor = System.Drawing.Color.LimeGreen
        Me.t30.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t30.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t30.Location = New System.Drawing.Point(1300, 514)
        Me.t30.Name = "t30"
        Me.t30.Size = New System.Drawing.Size(42, 25)
        Me.t30.TabIndex = 210
        Me.t30.Text = "t30"
        '
        't29
        '
        Me.t29.AutoSize = True
        Me.t29.BackColor = System.Drawing.Color.LimeGreen
        Me.t29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t29.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t29.Location = New System.Drawing.Point(1300, 475)
        Me.t29.Name = "t29"
        Me.t29.Size = New System.Drawing.Size(42, 25)
        Me.t29.TabIndex = 209
        Me.t29.Text = "t29"
        '
        't1
        '
        Me.t1.AutoSize = True
        Me.t1.BackColor = System.Drawing.Color.LimeGreen
        Me.t1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t1.Location = New System.Drawing.Point(263, 454)
        Me.t1.Name = "t1"
        Me.t1.Size = New System.Drawing.Size(30, 25)
        Me.t1.TabIndex = 208
        Me.t1.Text = "t1"
        '
        't2
        '
        Me.t2.AutoSize = True
        Me.t2.BackColor = System.Drawing.Color.LimeGreen
        Me.t2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t2.Location = New System.Drawing.Point(337, 454)
        Me.t2.Name = "t2"
        Me.t2.Size = New System.Drawing.Size(30, 25)
        Me.t2.TabIndex = 207
        Me.t2.Text = "t2"
        '
        't48
        '
        Me.t48.AutoSize = True
        Me.t48.BackColor = System.Drawing.Color.LimeGreen
        Me.t48.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t48.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t48.Location = New System.Drawing.Point(433, 772)
        Me.t48.Name = "t48"
        Me.t48.Size = New System.Drawing.Size(42, 25)
        Me.t48.TabIndex = 206
        Me.t48.Text = "t48"
        '
        't47
        '
        Me.t47.AutoSize = True
        Me.t47.BackColor = System.Drawing.Color.LimeGreen
        Me.t47.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t47.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t47.Location = New System.Drawing.Point(500, 772)
        Me.t47.Name = "t47"
        Me.t47.Size = New System.Drawing.Size(42, 25)
        Me.t47.TabIndex = 205
        Me.t47.Text = "t47"
        '
        't46
        '
        Me.t46.AutoSize = True
        Me.t46.BackColor = System.Drawing.Color.LimeGreen
        Me.t46.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t46.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t46.Location = New System.Drawing.Point(565, 772)
        Me.t46.Name = "t46"
        Me.t46.Size = New System.Drawing.Size(42, 25)
        Me.t46.TabIndex = 204
        Me.t46.Text = "t46"
        '
        't45
        '
        Me.t45.AutoSize = True
        Me.t45.BackColor = System.Drawing.Color.LimeGreen
        Me.t45.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t45.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t45.Location = New System.Drawing.Point(632, 772)
        Me.t45.Name = "t45"
        Me.t45.Size = New System.Drawing.Size(42, 25)
        Me.t45.TabIndex = 203
        Me.t45.Text = "t45"
        '
        't44
        '
        Me.t44.AutoSize = True
        Me.t44.BackColor = System.Drawing.Color.LimeGreen
        Me.t44.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t44.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t44.Location = New System.Drawing.Point(697, 772)
        Me.t44.Name = "t44"
        Me.t44.Size = New System.Drawing.Size(42, 25)
        Me.t44.TabIndex = 202
        Me.t44.Text = "t44"
        '
        't43
        '
        Me.t43.AutoSize = True
        Me.t43.BackColor = System.Drawing.Color.LimeGreen
        Me.t43.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t43.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t43.Location = New System.Drawing.Point(766, 772)
        Me.t43.Name = "t43"
        Me.t43.Size = New System.Drawing.Size(42, 25)
        Me.t43.TabIndex = 201
        Me.t43.Text = "t43"
        '
        't42
        '
        Me.t42.AutoSize = True
        Me.t42.BackColor = System.Drawing.Color.LimeGreen
        Me.t42.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t42.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t42.Location = New System.Drawing.Point(832, 772)
        Me.t42.Name = "t42"
        Me.t42.Size = New System.Drawing.Size(42, 25)
        Me.t42.TabIndex = 200
        Me.t42.Text = "t42"
        '
        't41
        '
        Me.t41.AutoSize = True
        Me.t41.BackColor = System.Drawing.Color.LimeGreen
        Me.t41.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t41.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t41.Location = New System.Drawing.Point(959, 772)
        Me.t41.Name = "t41"
        Me.t41.Size = New System.Drawing.Size(42, 25)
        Me.t41.TabIndex = 199
        Me.t41.Text = "t41"
        '
        't40
        '
        Me.t40.AutoSize = True
        Me.t40.BackColor = System.Drawing.Color.LimeGreen
        Me.t40.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t40.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t40.Location = New System.Drawing.Point(1029, 772)
        Me.t40.Name = "t40"
        Me.t40.Size = New System.Drawing.Size(42, 25)
        Me.t40.TabIndex = 198
        Me.t40.Text = "t40"
        '
        't39
        '
        Me.t39.AutoSize = True
        Me.t39.BackColor = System.Drawing.Color.LimeGreen
        Me.t39.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t39.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t39.Location = New System.Drawing.Point(1094, 772)
        Me.t39.Name = "t39"
        Me.t39.Size = New System.Drawing.Size(42, 25)
        Me.t39.TabIndex = 197
        Me.t39.Text = "t39"
        '
        't38
        '
        Me.t38.AutoSize = True
        Me.t38.BackColor = System.Drawing.Color.LimeGreen
        Me.t38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t38.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t38.Location = New System.Drawing.Point(1163, 772)
        Me.t38.Name = "t38"
        Me.t38.Size = New System.Drawing.Size(42, 25)
        Me.t38.TabIndex = 196
        Me.t38.Text = "t38"
        '
        't37
        '
        Me.t37.AutoSize = True
        Me.t37.BackColor = System.Drawing.Color.LimeGreen
        Me.t37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t37.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t37.Location = New System.Drawing.Point(1229, 772)
        Me.t37.Name = "t37"
        Me.t37.Size = New System.Drawing.Size(42, 25)
        Me.t37.TabIndex = 195
        Me.t37.Text = "t37"
        '
        't36
        '
        Me.t36.AutoSize = True
        Me.t36.BackColor = System.Drawing.Color.LimeGreen
        Me.t36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t36.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t36.Location = New System.Drawing.Point(1304, 729)
        Me.t36.Name = "t36"
        Me.t36.Size = New System.Drawing.Size(42, 25)
        Me.t36.TabIndex = 194
        Me.t36.Text = "t36"
        '
        't35
        '
        Me.t35.AutoSize = True
        Me.t35.BackColor = System.Drawing.Color.LimeGreen
        Me.t35.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t35.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t35.Location = New System.Drawing.Point(1303, 694)
        Me.t35.Name = "t35"
        Me.t35.Size = New System.Drawing.Size(42, 25)
        Me.t35.TabIndex = 193
        Me.t35.Text = "t35"
        '
        't49
        '
        Me.t49.AutoSize = True
        Me.t49.BackColor = System.Drawing.Color.LimeGreen
        Me.t49.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t49.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t49.Location = New System.Drawing.Point(366, 772)
        Me.t49.Name = "t49"
        Me.t49.Size = New System.Drawing.Size(42, 25)
        Me.t49.TabIndex = 192
        Me.t49.Text = "t49"
        '
        't50
        '
        Me.t50.AutoSize = True
        Me.t50.BackColor = System.Drawing.Color.LimeGreen
        Me.t50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t50.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.t50.Location = New System.Drawing.Point(300, 772)
        Me.t50.Name = "t50"
        Me.t50.Size = New System.Drawing.Size(42, 25)
        Me.t50.TabIndex = 191
        Me.t50.Text = "t50"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Teal
        Me.Panel1.BackgroundImage = Global.Parking_Management_System.My.Resources.Resources.color
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(2042, 60)
        Me.Panel1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Footlight MT Light", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(1041, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(342, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Parking Management System"
        '
        'park
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1924, 1055)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Name = "park"
        Me.Text = "PARK"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents f11 As System.Windows.Forms.Label
    Friend WithEvents f13 As System.Windows.Forms.Label
    Friend WithEvents f9 As System.Windows.Forms.Label
    Friend WithEvents f18 As System.Windows.Forms.Label
    Friend WithEvents f20 As System.Windows.Forms.Label
    Friend WithEvents f16 As System.Windows.Forms.Label
    Friend WithEvents f17 As System.Windows.Forms.Label
    Friend WithEvents f19 As System.Windows.Forms.Label
    Friend WithEvents f15 As System.Windows.Forms.Label
    Friend WithEvents f12 As System.Windows.Forms.Label
    Friend WithEvents f14 As System.Windows.Forms.Label
    Friend WithEvents f10 As System.Windows.Forms.Label
    Friend WithEvents f5 As System.Windows.Forms.Label
    Friend WithEvents f7 As System.Windows.Forms.Label
    Friend WithEvents f3 As System.Windows.Forms.Label
    Friend WithEvents f1 As System.Windows.Forms.Label
    Friend WithEvents f6 As System.Windows.Forms.Label
    Friend WithEvents f8 As System.Windows.Forms.Label
    Friend WithEvents f4 As System.Windows.Forms.Label
    Friend WithEvents f2 As System.Windows.Forms.Label
    Friend WithEvents t18 As System.Windows.Forms.Label
    Friend WithEvents t19 As System.Windows.Forms.Label
    Friend WithEvents t20 As System.Windows.Forms.Label
    Friend WithEvents t17 As System.Windows.Forms.Label
    Friend WithEvents t16 As System.Windows.Forms.Label
    Friend WithEvents t13 As System.Windows.Forms.Label
    Friend WithEvents t14 As System.Windows.Forms.Label
    Friend WithEvents t15 As System.Windows.Forms.Label
    Friend WithEvents t12 As System.Windows.Forms.Label
    Friend WithEvents t11 As System.Windows.Forms.Label
    Friend WithEvents t5 As System.Windows.Forms.Label
    Friend WithEvents t6 As System.Windows.Forms.Label
    Friend WithEvents t7 As System.Windows.Forms.Label
    Friend WithEvents t8 As System.Windows.Forms.Label
    Friend WithEvents t9 As System.Windows.Forms.Label
    Friend WithEvents t10 As System.Windows.Forms.Label
    Friend WithEvents t3 As System.Windows.Forms.Label
    Friend WithEvents t4 As System.Windows.Forms.Label
    Friend WithEvents t26 As System.Windows.Forms.Label
    Friend WithEvents t25 As System.Windows.Forms.Label
    Friend WithEvents t24 As System.Windows.Forms.Label
    Friend WithEvents t23 As System.Windows.Forms.Label
    Friend WithEvents t22 As System.Windows.Forms.Label
    Friend WithEvents t21 As System.Windows.Forms.Label
    Friend WithEvents t28 As System.Windows.Forms.Label
    Friend WithEvents t27 As System.Windows.Forms.Label
    Friend WithEvents t34 As System.Windows.Forms.Label
    Friend WithEvents t33 As System.Windows.Forms.Label
    Friend WithEvents t32 As System.Windows.Forms.Label
    Friend WithEvents t31 As System.Windows.Forms.Label
    Friend WithEvents t30 As System.Windows.Forms.Label
    Friend WithEvents t29 As System.Windows.Forms.Label
    Friend WithEvents t1 As System.Windows.Forms.Label
    Friend WithEvents t2 As System.Windows.Forms.Label
    Friend WithEvents t48 As System.Windows.Forms.Label
    Friend WithEvents t47 As System.Windows.Forms.Label
    Friend WithEvents t46 As System.Windows.Forms.Label
    Friend WithEvents t45 As System.Windows.Forms.Label
    Friend WithEvents t44 As System.Windows.Forms.Label
    Friend WithEvents t43 As System.Windows.Forms.Label
    Friend WithEvents t42 As System.Windows.Forms.Label
    Friend WithEvents t41 As System.Windows.Forms.Label
    Friend WithEvents t40 As System.Windows.Forms.Label
    Friend WithEvents t39 As System.Windows.Forms.Label
    Friend WithEvents t38 As System.Windows.Forms.Label
    Friend WithEvents t37 As System.Windows.Forms.Label
    Friend WithEvents t36 As System.Windows.Forms.Label
    Friend WithEvents t35 As System.Windows.Forms.Label
    Friend WithEvents t49 As System.Windows.Forms.Label
    Friend WithEvents t50 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
End Class
